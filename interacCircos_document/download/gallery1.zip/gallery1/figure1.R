library(interacCircos)
#https://www.researchgate.net/figure/Circos-plot-indicating-QTL-involved-in-net-blotch-resistance-ie-average-ordinate-AO_fig1_320636535
#This plot indicating QTL involved in net blotch resistance, i.e. average ordinate (AO) and reaction type (RT). The barley chromosomes are
#arranged as coloured bars forming the most inner circle. Centromere regions are highlighted as transparent boxes. (A)The Grey connector lines
#represent the genetic position of the 5,715 informative SNPs on the chromosomes with cM positions given on the scale on
#the outside of circle E. (B) Marker trait associations calculated for reaction type (RT). Bars identify the position and detection rate (DR, height of bars) of significant marker trait associations. Bars in blue, pointing inwards, indicate a population wide traitdecreasing effect exerted by the exotic allele, whereas bars in red, pointing outwards, indicate a population wide trait-increasing effect exerted by the exotic allele. The grey and orange lines depict the DR threshold of 10% and 50% across 200 cross-validation runs. (C) Count of significant marker trait associations within 5cM intervals for the NAM study based on RT data. (D) Marker trait associations calculated for average ordinate (AO). Graphical representation as described under (A). (E) Count of significant marker trait associations within 5cM intervals for the NAM study based on AO data. The position of particularly robust QTL with DR >50% are indicated on the scale outside of circle E. QTL detected based on RT are shown in red, whereas QTL detected based on AO are shown in purple.

#Prepare data for barcode
setwd("/Users/cuizhe")
barcode<-read.table("barcode.txt")
colnames(barcode)<-c("chr","start","end","color")

#prepare data for arc inside barcode
arc1<-read.table("arc.txt")
colnames(arc1)<-c("chr","start","end","color")

#Prepare data for histogram module
histogram_blue<-read.table("histogram_blue.txt")
colnames(histogram_blue)<-c("chr","start","end","value")
histogram_blue2<-read.table("histogram_blue2.txt")
colnames(histogram_blue2)<-c("chr","start","end","value")
histogram_blue3<-read.table("histogram_blue3.txt")
colnames(histogram_blue3)<-c("chr","start","end","value")
histogram_red<-read.table("histogram_red.txt")
colnames(histogram_red)<-c("chr","start","end","value")
histogram_red2<-read.table("histogram_red2.txt")
colnames(histogram_red2)<-c("chr","start","end","value")
histogram_red3<-read.table("histogram_red3.txt")
colnames(histogram_red3)<-c("chr","start","end","value")

#prepare data for link module
link_red<-read.table("link_red.txt")
colnames(link_red)<-c("fusion","g1chr","g1start","g1end","g2chr","g2start",'g2end')
link_blue<-read.table("link_blue.txt")
colnames(link_blue)<-c("fusion","g1chr","g1start","g1end","g2chr","g2start",'g2end')

moduleList<-CircosBackground("bg01",minRadius =242,maxRadius = 214,fillColors = "white",borderSize = 0,axisShow = TRUE,
                                   axisNum = 6,axisWidth = 0.1)+
  CircosBackground("bg02",maxRadius = 212,minRadius =167,borderSize = 0,fillColors = "rgb(176,173,210)")+
  CircosBackground("bg03",maxRadius = 166,minRadius = 138,borderSize = 0,fillColors = "white",axisShow = TRUE,
                          axisNum = 6,axisWidth = 0.1)+
  CircosBackground("bg04",maxRadius = 136,minRadius = 91,borderSize = 0,fillColors = "rgb(251,199,178)")+
  CircosArc("arc01",outerRadius = 90,innerRadius = 75,data = barcode)+
  CircosArc("arc02",outerRadius = 73,innerRadius = 66,data = arc1)+
  CircosHistogram("histogram01",maxRadius = 242,minRadius = 214,ValueAxisManualScale = TRUE,ValueAxisMaxScale = 70,
                         fillColor = "rgb(55,51,142)",data = histogram_blue)+
  CircosHistogram("histogram02",maxRadius = 166,minRadius = 138,ValueAxisManualScale = TRUE,ValueAxisMaxScale = 70,
                         fillColor = "rgb(108,0,1)",data = histogram_blue)+
  CircosBackground("bg05",minRadius =200,maxRadius = 179,fillColors = "rgb(213,212,233)",borderSize = 0.5,borderColors = "red")+
  CircosBackground("bg06",minRadius =124,maxRadius = 103,fillColors = "rgb(253,223,209)",borderSize = 0.5,borderColors = "red")+
  CircosBackground("bg07",minRadius =192,maxRadius = 188,fillColors = "white",borderSize = 0.2,borderColors = "black")+
  CircosBackground("bg07",minRadius =115,maxRadius = 111,fillColors = "white",borderSize = 0.2,borderColors = "black")+
  CircosHistogram("histogram03",maxRadius = 211,minRadius = 190,fillColor = "rgb(108,0,1)",data = histogram_red2)+
  CircosHistogram("histogram04",maxRadius = 135,minRadius = 113,fillColor = "rgb(108,0,1)",data = histogram_red3)+
  CircosHistogram("histogram05",maxRadius = 168,minRadius = 190,fillColor = "rgb(55,51,142)",data = histogram_blue2)+
  CircosHistogram("histogram06",maxRadius = 92,minRadius = 113,fillColor = "rgb(55,51,142)",data = histogram_blue3)+
  CircosLink("link01",radius = 260,width = 0,data =link_red)+
  CircosLink("link02",radius = 260,width = 0,data =link_blue,labelColor = "purple")+
  CircosText("text01",text = "A",x = 75,y = 20,size = 15)+
  CircosText("text02",text = "B",x = 110,y = 27,size = 15)+
  CircosText("text03",text = "C",x = 150,y = 36,size = 15)+
  CircosText("text04",text = "D",x = 180,y = 42,size = 15)+
  CircosText("text05",text = "E",x = 220,y = 50,size = 15)

Circos(moduleList = moduleList,genome = list("1H"=135,"2H"=150,"3H"=155,"4H"=115,"5H"=170,"6H"=130,"7H"=145),
         genomeFillColor = c("white","white","white","white","white","white","white"),
         genomeTicksDisplay =TRUE,genomeTicksRealLength=TRUE, genomeTicksScale = 5, genomeTicksLen = 3,
         genomeTicksTextSize = "0.4em",genomeLabelDy = 200,outerRadius = 243, innerRadius = 242,chrPad = 0.05,width = 800,height = 600)

