library(interacCircos)
#https://www.nature.com/articles/ng.2669
#This figure displays the comparative genomic mapping in C. rubella(CR), A. lyrata(AL).
#The outer ring shows the percentage of the genomic window that comprises transposable elements, the second ring shows gene density, and the
#inner ring shows orthologous regions between species on the basis of whole-genome alignment and orthologous chaining. Note that the
#A. lyrata, but not the C. rubella, assembly includes gaps for inferred centromeric heterochromatin. From synteny analyses
#of the three species, the approximate gene intervals contained within each block include: A/B, AT1G01010–AT1G36980; C, AT1G41830–AT1G56200;
#D, AT1G56210–AT1G64720; E, AT1G64790–AT1G80950; F, AT3G01070–AT3G25530; G, AT2G04039–AT2G07050; H, AT2G10870–AT2G20900; I, AT2G20920–AT2G26430;
#J, AT2G26670–AT2G48160; K, AT2G01060–AT2G04038; L, AT3G25545–AT3G32980; M/N, AT3G42170–AT3G63490; O, AT4G00026–AT4G05530; P, AT4G06534–AT4G12590;
#Q/R, AT5G01010–AT5G30510; S, AT5G32440–AT5G42110; T/U, AT4G12640–AT4G40100; V, AT5G42140–AT5G47760; W/X, AT5G47800–AT5G67640.

setwd("/Users/cuizhe")
#Prepare data for chord
chordData<-read.table("chord.txt",header = TRUE,row.names = 1)

#Prepare data for line module
wig1<-read.table("wig1.txt")
colnames(wig1)<-c("chr","pos","value")
wig2<-read.table("wig2.txt")
colnames(wig2)<-c("chr","pos","value")
wig3<-read.table("wig3.txt")
colnames(wig3)<-c("chr","pos","value")
wig4<-read.table("wig4.txt")
colnames(wig4)<-c("chr","pos","value")

moduleList<-CircosChord("chord01",data = chordData,outerRadius = 145,innerRadius = 145,padding = 0.04,outerARCText = FALSE,
                              fillColor = c("Yellow","Yellow","red","red","red","rgb(67,76,157)","rgb(67,76,157)","rgb(211,90,156)",
                                            "rgb(211,90,156)","orange","orange","green","green","rgb(23,171,199)","rgb(23,171,199)","pink",
                                            "pink","rgb(23,171,199)"),
                              autoFillColor = FALSE,outerARC = FALSE)+
  CircosWig("wig01",data = wig1,minRadius = 195,maxRadius = 215,color = "green",strokeColor = "green",strokeType = "linear")+
  CircosWig("wig02",data = wig2,minRadius = 195,maxRadius = 215,color = "rgb(23,171,199)",strokeColor = "rgb(23,171,199)",
                   strokeType = "linear")+
  CircosWig("wig03",data = wig3,minRadius = 235,maxRadius = 255,color = "yellow",strokeColor = "yellow",strokeType = "linear")+
  CircosWig("wig04",data = wig4,minRadius = 235,maxRadius = 255,color = "red",strokeColor = "red",strokeType = "linear")+
  CircosBackground("bg01",maxRadius = 215,minRadius =195,borderSize = 0.5,fillColors = "white")


Circos(moduleList = moduleList,genome = list("AL1"=33,"AL2"=19,"AL3"=24,"AL4"=23,"AL5"=21,"AL6"=25,"AL7"=25,"AL8"=23,"AL9"=2,"CR8"=13,
                                            "CR7"=17,"CR6"=16,"CR5"=14,"CR4"=15,"CR3"=15,"CR2"=14,"CR1"=20),
         genomeFillColor = c("rgb(177,218,176)","rgb(177,218,176)","rgb(177,218,176)","rgb(177,218,176)","rgb(177,218,176)","rgb(177,218,176)",
                             "rgb(177,218,176)","rgb(177,218,176)","rgb(177,218,176)","rgb(241,156,144)","rgb(19,163,195)","rgb(22,152,67)",
                             "rgb(243,128,28)","rgb(200,62,143)","rgb(43,63,147)","rgb(228,21,39)","rgb(235,232,16)"),
         genomeTicksDisplay =FALSE,genomeLabelDy =1,genomeLabelDx =0.05,outerRadius = 170, innerRadius = 150,chrPad = 0.04,width = 800,
         height = 600)

