## ----eval=FALSE, screenshot.force=FALSE---------------------------------------
#  # You need devtools for that
#  if (!require('devtools')){install.packages('devtools')}
#  
#  devtools::install_github('mrcuizhe/rNGCircos', build_vignettes = TRUE)

## ----plot1,fig.width=7, fig.height=6,echo=TRUE--------------------------------

library(rNGCircos)
rNGCircos(zoom=FALSE)


## ----plot2,fig.width=7, fig.height=6,echo=TRUE, screenshot.force = FALSE------
library(rNGCircos)

rNGCircos(zoom = FALSE,genome=list("Example1"=100,"Example2"=200,"Example3"=300),genomeFillColor = c("red","blue","green"))


## ----plot3, fig.width=7, fig.height=6,echo=TRUE, screenshot.force = FALSE-----
library(rNGCircos)

rNGCircos(genome=list("Example1"=100,"Example2"=200,"Example3"=300),genomeFillColor = "Blues")

## ----plot4, fig.width=7, fig.height=6,echo=TRUE-------------------------------
library(rNGCircos)
rNGCircos(genome=list("Example1"=100,"Example2"=200,"Example3"=300),genomeFillColor = "Blues",chrPad = 0,genomeTicksDisplay = TRUE,genomeTicksScale = 10,genomeLabelDisplay = FALSE)

## ----plot5, fig.width=7, fig.height=6,echo=TRUE-------------------------------
library(rNGCircos)
moduleList<-rNGCircosText('text01', 'Annotation', color = '#DD2222', x = -40) + rNGCircosBackground('bg01', fillColors="#FFEEEE", borderSize = 1)
rNGCircos(moduleList = moduleList)

## ----plot6, fig.width=7, fig.height=6,echo=TRUE-------------------------------
library(rNGCircos)
rNGCircos(rNGCircosAuxLine('AuxLine01'))

## ----plot7, fig.width=7, fig.height=6,echo=TRUE-------------------------------
library(rNGCircos) 
rNGCircos(rNGCircosBackground('bg01', fillColors="#FFEEEE", borderSize = 1))

## ----plot8, fig.width=7, fig.height=6,echo=TRUE-------------------------------
library(rNGCircos)
bubbleData<-bubbleExample
rNGCircos(rNGCircosBubble('Bubble01', maxRadius = 230, minRadius = 170, data=bubbleData, blockStroke = TRUE, bubbleMaxSize =10, bubbleMinSize = 2, maxColor = "red", minColor = "yellow", totalLayer =3, animationDisplay = TRUE, animationType="linear"),genome = list("2L"=23011544,"2R"=21146708,"3L"=24543557,"3R"= 27905053,"X"=22422827,"4"=1351857), BUBBLEMouseOverDisplay =TRUE,innerRadius = 236)

## ----plot9, fig.width=7, fig.height=6,echo=TRUE-------------------------------
library(rNGCircos)
chordData<-chordExample
rNGCircos(rNGCircosChord('CHORD01', data = chordData,innerRadius= 210,outerRadius= 211,fillOpacity=0.67,
strokeColor="black",strokeWidth= "1px",outerARCText=FALSE),genome=list("C.CK" = 189.51,"C.NPK"=188,"GC.CK"=186.11,
"GC.NPK"=191.51,"Alphaproteobacteria"=70.16,"Betaproteobacteria"=23.51,"Gammaproteobacteria"=25.51,
"Deltaproteobacteria"=23.28,"Acidobacteria"=53.62,"Actinobacteria"=72.33,"Bacteroidetes"=22.41,
"Chloroflexi"=15.08,"Firmicutes"=10.72,"Gemmatimonadetes"=26.37,"Planctomycetes"=19.26,"Thaumarchaeota"=6.15,
"Verrucomicrobia"=8.3,"Ascomycota"=159.41,"Basidiomycota"=79.73,"Zygomycota"=139.29 ),outerRadius = 217,
genomeLabelDisplay = FALSE)

## ----plot10, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
cnvData<-cnvExample
rNGCircos(rNGCircosCnv('Cnv01',maxRadius =175, minRadius =116, data =cnvData,width=2,color = "#4876FF")+
rNGCircosBackground("bg01",minRadius = 116,maxRadius = 175,fillColors = "#F2F2F2",axisShow = TRUE),CNVMouseOverDisplay = TRUE)

## ----plot11, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
geneData<-geneExample
rNGCircos(rNGCircosGene('Gene01', outerRadius = 195, innerRadius = 180, data=geneData,arrowGap = 10,
 arrowColor = "black",arrowSize = "12px",cdsColor = "#1e77b3",cdsStrokeColor = "#1e77b3",cdsStrokeWidth= 5,
 utrWidth= -2,utrColor= "#fe7f0e",utrStrokeColor= "#fe7f0e",animationDisplay = TRUE),genome =list("EGFR"=1000),
 outerRadius = 220)

## ----plot12, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
heatmapData<-heatmapExample
rNGCircos(rNGCircosHeatmap('Heatmap01', maxRadius= 180, minRadius = 100, data=heatmapData,totalLayer = 3),
genome = list("2L"=23011544,"2R"=21146708,"3L"=24543557,"3R"=27905053,"4"=1351857,"X"=22422827),
HEATMAPMouseEvent = TRUE,HEATMAPMouseOverDisplay = TRUE)

## ----plot13, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
histogramData<-histogramExample
rNGCircos(rNGCircosHistogram('HISTOGRAM01', data = histogramData,fillColor= "#ff7f0e",maxRadius = 210,
minRadius = 175),genome=list("2L"=23011544,"2R"=21146708,"3L"=24543557,"3R"= 27905053,"X"=22422827,"4"=1351857),
outerRadius = 220)

## ----plot14, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
legend1 <- list(type= "circle", color="#1E77B4",opacity="1.0",circleSize="8",text= "C.CK", textSize= "14",textWeight="normal")
legend2 <- list(type= "circle", color="#AEC7E8",opacity="1.0",circleSize="8",text= "C.NPK", textSize= "14",textWeight="normal")
rNGCircos(rNGCircosLegend('legend01', title = "legend",data=list(legend1,legend2),size = 20))

## ----plot15, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
lineData<-lineExample
rNGCircos(rNGCircosLine('LINE01', data = lineData,maxRadius=200,minRadius=150,color= "#ff0031")+
rNGCircosBackground('BG01',minRadius = 205,maxRadius = 150))

## ----plot16, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
linkData<-linkExample
rNGCircos(rNGCircosLink('LINK01', data = linkData,LinkRadius= 140,fillColor= "#9e9ac6",width= 2,
axisPad= 3,labelPad=8,animationDisplay=TRUE,animationDirection="1to2", animationType= "linear" ))

## ----plot17, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
lollipopData<-lollipopExample
arcData<-arcExample
rNGCircos(rNGCircosLollipop('Lollipop01', data=lollipopData, fillColor="#9400D3",
circleSize= 6, strokeColor= "#999999", strokeWidth= "1px", animationDisplay=TRUE, lineWidth= 2,
realStart= 101219350)+rNGCircosArc('Arc01', outerRadius = 212, innerRadius = 224, data=arcData),
 genome=list("EGFR"=1211),outerRadius = 220,genomeFillColor = c("grey"))

## ----plot18, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
snpData<-snpExample
rNGCircos(rNGCircosSnp('SNP01', minRadius =150, maxRadius = 190, data = snpExample,SNPFillColor= "#9ACD32", circleSize= 2, SNPAxisColor= "#B8B8B8", SNPAxisWidth= 0.5, SNPAnimationDisplay=TRUE,SNPAnimationTime= 2000, SNPAnimationDelay= 0, SNPAnimationType= "linear") + rNGCircosBackground('BG01',minRadius = 145,maxRadius = 200))

## ----plot19, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)  
rNGCircos(rNGCircosText('text01', 'Annotation', color = '#DD2222', x = -40))

## ----plot20, fig.width=7, fig.height=6,echo=TRUE------------------------------
library(rNGCircos)
wigData<-wigExample
rNGCircos(rNGCircosWig('WIG01', data = wigData, maxRadius= 200,minRadius= 150,strokeColor= "darkblue",
color= "lightblue",strokeType= "cardinal")+rNGCircosBackground('BG01',minRadius = 205,maxRadius = 150)
,genome=list("chr8"=1000),outerRadius = 220)

## ----eval=FALSE, screenshot.force = FALSE-------------------------------------
#  library(rNGCircos)
#  library(htmlwidgets)
#  
#  wigData<-wigExample
#  plot <- rNGCircos(rNGCircosWig('WIG01', data = wigData, maxRadius= 200,minRadius= 150,strokeColor= "darkblue",
#  color= "lightblue",strokeType= "cardinal")+rNGCircosBackground('BG01',minRadius = 205,maxRadius = 150)
#  ,genome=list("chr8"=1000),outerRadius = 220)
#  
#  saveWidget(plot, "plot.html")

